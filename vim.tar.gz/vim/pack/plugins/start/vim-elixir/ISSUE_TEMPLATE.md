Filing a bug? Have you already tried updating `vim-elixir`? For indentation/highlighting bugs, please use the following template:

# Actual

```ex
Example code
```

# Expected

```ex
Example code
```
