defmodule ElixirSenseTest do
  use ExUnit.Case

  doctest ElixirSense
end
